-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 05, 2023 at 03:30 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `firmasdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(30) NOT NULL,
  `action_made` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `user_id`, `action_made`, `date_created`) VALUES
(1, 1, 'Inicio sesion.', '2023-05-20 00:06:36'),
(2, 1, 'Inicio sesion.', '2023-05-20 00:40:34'),
(3, 1, 'Cerro sesion.', '2023-05-20 00:54:27'),
(4, 1, 'Inicio sesion.', '2023-05-20 00:54:36'),
(5, 1, 'Cerro sesion.', '2023-05-20 00:56:55'),
(6, 1, 'Inicio sesion.', '2023-05-20 00:57:05'),
(7, 1, 'Inicio sesion.', '2023-05-20 11:32:19'),
(8, 1, ' Vio detalles de [id=1]Clairy Blake', '2023-05-20 11:56:03'),
(9, 1, ' Vio detalles de [id=1]Clairy Blake', '2023-05-20 11:56:35'),
(10, 1, ' Vio detalles de [id=1]Clairy Blake', '2023-05-20 11:59:02'),
(11, 1, ' Vio detalles de [id=2]John Smith', '2023-05-20 11:59:12'),
(12, 1, ' Vio detalles de [id=2]John Smith', '2023-05-20 11:59:38'),
(13, 1, ' Vio detalles de [id=5]Mikee Williams', '2023-05-20 12:18:12'),
(14, 1, 'Cerro sesion.', '2023-05-20 12:22:25'),
(15, 1, 'Inicio sesion.', '2023-05-20 12:22:31'),
(16, 1, 'Cerro sesion.', '2023-05-20 12:28:00'),
(17, 3, 'Inicio sesion.', '2023-05-20 12:28:12'),
(18, 3, ' Vio detalles de [id=1]Clairy Blake', '2023-05-20 12:28:17'),
(19, 3, ' Usuario [id=2] editado.', '2023-05-20 12:28:30'),
(20, 3, ' Usuario [id=5] editado.', '2023-05-20 12:31:02'),
(21, 1, 'Inicio sesion.', '2023-05-20 13:48:38'),
(22, 1, 'Cerro sesion.', '2023-05-20 13:52:32'),
(23, 1, 'Inicio sesion.', '2023-05-20 14:00:44'),
(24, 1, 'Inicio sesion.', '2023-05-20 23:02:42'),
(25, 1, ' Usuario [id=2] editado.', '2023-05-20 23:34:02'),
(26, 1, ' Usuario [id=1] editado.', '2023-05-20 23:34:38'),
(27, 3, 'Inicio sesion.', '2023-05-20 23:37:44'),
(28, 3, 'Cerro sesion.', '2023-05-20 23:37:58'),
(29, 1, 'Inicio sesion.', '2023-05-20 23:45:09'),
(30, 3, 'Inicio sesion.', '2023-05-21 12:45:25'),
(31, 3, ' Vio detalles de [id=1]Clara Becker', '2023-05-21 13:14:48'),
(32, 1, 'Inicio sesion.', '2023-05-22 09:23:43'),
(33, 1, 'Inicio sesion.', '2023-05-22 22:23:12'),
(34, 1, 'Inicio sesion.', '2023-05-23 20:25:20'),
(35, 1, 'Inicio sesion.', '2023-05-24 10:04:32'),
(36, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 11:38:55'),
(37, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 11:53:35'),
(38, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 11:54:04'),
(39, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 11:56:07'),
(40, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 11:56:43'),
(41, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 12:09:30'),
(42, 1, 'Inicio sesion.', '2023-05-24 14:11:29'),
(43, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 14:14:25'),
(44, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 14:14:54'),
(45, 1, ' anadio [id=] a la lista de usuarios.', '2023-05-24 14:17:14'),
(46, 1, ' Firma [id=1.0] actualizada.', '2023-05-24 14:21:25'),
(47, 1, ' Firma [id=1.0] actualizada.', '2023-05-24 14:25:49'),
(48, 3, 'Inicio sesion.', '2023-05-24 23:06:24'),
(51, 8, 'Inicio sesion.', '2023-05-25 13:00:46'),
(52, 8, ' Firma [id=6.0] actualizada.', '2023-05-25 13:01:16'),
(53, 1, 'Inicio sesion.', '2023-05-25 20:56:19'),
(54, 1, 'Cerro sesion.', '2023-05-25 20:56:57'),
(55, 1, 'Inicio sesion.', '2023-05-29 09:00:28'),
(56, 1, 'Inicio sesion.', '2023-05-29 09:13:54'),
(57, 1, 'Cerro sesion.', '2023-05-29 09:17:05'),
(58, 1, 'Inicio sesion.', '2023-05-29 09:21:10'),
(59, 1, 'Cerro sesion.', '2023-05-29 10:25:12'),
(60, 1, 'Inicio sesion.', '2023-05-29 10:25:16'),
(61, 1, 'Inicio sesion.', '2023-05-29 11:07:30'),
(62, 1, 'Inicio sesion.', '2023-05-29 11:26:19'),
(63, 1, 'Inicio sesion.', '2023-05-29 12:55:20'),
(64, 1, 'Cerro sesion.', '2023-05-29 12:56:32'),
(65, 1, 'Inicio sesion.', '2023-05-29 13:37:43'),
(66, 1, 'Cerro sesion.', '2023-05-29 13:40:05'),
(67, 1, 'Inicio sesion.', '2023-05-29 13:40:11'),
(68, 1, 'Inicio sesion.', '2023-05-29 19:34:02'),
(69, 1, ' Firma [id=6.0] actualizada.', '2023-05-29 19:52:22'),
(70, 1, 'Inicio sesion.', '2023-05-31 08:10:56'),
(71, 1, 'Inicio sesion.', '2023-05-31 08:11:03'),
(72, 1, 'Inicio sesion.', '2023-05-31 08:11:27'),
(73, 1, 'Inicio sesion.', '2023-05-31 08:11:28'),
(74, 1, 'Cerro sesion.', '2023-05-31 08:12:21'),
(75, 1, 'Inicio sesion.', '2023-05-31 08:12:25'),
(76, 1, 'Cerro sesion.', '2023-05-31 08:13:53'),
(77, 1, 'Inicio sesion.', '2023-05-31 08:13:58'),
(78, 1, 'Cerro sesion.', '2023-05-31 08:22:23'),
(79, 1, 'Inicio sesion.', '2023-05-31 08:22:29'),
(80, 1, 'Inicio sesion.', '2023-06-02 08:04:19'),
(81, 1, 'Inicio sesion.', '2023-06-02 08:07:13'),
(82, 1, 'Cerro sesion.', '2023-06-02 08:16:28'),
(83, 1, 'Inicio sesion.', '2023-06-02 08:16:33'),
(84, 1, 'Inicio sesion.', '2023-06-02 08:37:47'),
(85, 1, 'Cerro sesion.', '2023-06-02 08:42:43'),
(86, 1, 'Inicio sesion.', '2023-06-02 08:42:48'),
(87, 1, 'Cerro sesion.', '2023-06-02 08:44:47'),
(88, 1, 'Inicio sesion.', '2023-06-02 08:44:51'),
(89, 1, 'Cerro sesion.', '2023-06-02 08:57:27'),
(90, 1, 'Inicio sesion.', '2023-06-02 08:57:31'),
(91, 1, 'Cerro sesion.', '2023-06-02 09:06:48'),
(92, 1, 'Inicio sesion.', '2023-06-02 09:06:51'),
(93, 1, 'Cerro sesion.', '2023-06-02 11:56:26'),
(94, 1, 'Inicio sesion.', '2023-06-02 11:56:54'),
(95, 1, 'Inicio sesion.', '2023-06-02 12:26:49'),
(96, 1, 'Inicio sesion.', '2023-06-02 13:41:24'),
(97, 1, 'Inicio sesion.', '2023-06-02 22:13:05'),
(98, 1, '[id=5.0] cambio la firma.', '2023-06-02 23:23:56'),
(100, 1, '[id=15.0] cambio la firma.', '2023-06-02 23:26:18'),
(101, 1, '[id=5.0] cambio la firma de [1.0].', '2023-06-02 23:27:26'),
(104, 1, '[id=7.0] cambio la firma de [1.0].', '2023-06-02 23:28:37'),
(105, 1, 'Inicio sesion.', '2023-06-03 10:24:22'),
(106, 1, '[id=5.0] cambio la firma de [1.0].', '2023-06-03 10:26:27'),
(107, 1, 'Inicio sesion.', '2023-06-03 15:54:42'),
(108, 9, 'Inicio sesion.', '2023-06-04 00:16:14'),
(111, 1, '[id=9.0] cambio la firma de [1.0].', '2023-06-04 00:17:26'),
(112, 1, '[id=13.0] cambio la firma de [1.0].', '2023-06-04 00:25:53'),
(113, 9, '[id=5.0] cambio la firma de [1.0].', '2023-06-04 00:32:31'),
(114, 9, 'Habilito la firma [id=53.0]', '2023-06-04 00:38:46'),
(115, 9, 'Cerro sesion.', '2023-06-04 00:59:09'),
(116, 1, 'Inicio sesion.', '2023-06-04 00:59:16'),
(117, 1, 'Inicio sesion.', '2023-06-04 01:23:26'),
(118, 1, 'Cerro sesion.', '2023-06-04 01:28:15'),
(119, 9, 'Inicio sesion.', '2023-06-04 01:28:20'),
(120, 9, 'Cerro sesion.', '2023-06-04 01:29:36'),
(121, 1, 'Inicio sesion.', '2023-06-04 01:29:43'),
(122, 1, 'se cambio por la firma de [6.0] por [id=13.0].', '2023-06-04 01:30:09'),
(123, 1, 'Habilito la firma [id=99.0]', '2023-06-04 01:30:21'),
(124, 1, 'Inicio sesion.', '2023-06-04 11:50:05'),
(125, 1, 'Habilito la firma [id=1.0]', '2023-06-04 11:50:17'),
(126, 1, 'Inicio sesion.', '2023-06-04 12:07:56'),
(127, 1, 'Cerro sesion.', '2023-06-04 12:10:11'),
(128, 9, 'Inicio sesion.', '2023-06-04 12:10:16'),
(129, 1, 'Inicio sesion.', '2023-06-04 12:11:12'),
(130, 1, 'Inicio sesion.', '2023-06-04 12:14:03'),
(131, 1, 'Inicio sesion.', '2023-06-04 12:16:32'),
(132, 1, 'Habilito la firma [id=6.0].', '2023-06-04 12:29:28'),
(133, 1, 'Habilito la firma [id=16.0].', '2023-06-04 12:34:42'),
(134, 1, 'Habilito la firma [id=18.0].', '2023-06-04 12:37:44'),
(135, 1, 'Inicio sesion.', '2023-06-04 22:27:47'),
(136, 1, 'se cambio por la firma de [1.0] por [id=6.0].', '2023-06-04 22:27:56'),
(137, 1, 'Habilito la firma [id=1.0].', '2023-06-04 22:28:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `date_created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `date_created`) VALUES
(1, 'Administrador', 'admin', '0192023a7bbd73250516f069df18b500', '2023-10-19 21:50:25'),
(3, 'Sistemas', 'sistemas', '74e0ff2809a2ca8be804b055c383b9f4', '2023-10-20 12:28:06'),
(8, 'augusto', 'augusto', '70dc9794fd98431263b895f1344860c7', NULL),
(9, 'jose', 'jose', '662eaa47199461d01a623884080934ab', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
